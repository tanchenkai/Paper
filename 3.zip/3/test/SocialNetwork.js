const SocialNetwork = artifacts.require('./SocialNetwork.sol')

require('chai')
  .use(require('chai-as-promised'))
  .should()

contract('SocialNetwork', ([deployer, author,tipper])=> {
  let socialNetwork

  before(async () =>{
    socialNetwork = await SocialNetwork.deployed()
  })

  describe('deployment', async ()=>{
    it('智能合约部署成功',async () =>{
      const address = await socialNetwork.address
      assert.notEqual(address, 0x0)
      assert.notEqual(address, '')
      assert.notEqual(address,null)
      assert.notEqual(address, undefined)
    })

    it('智能合约名称是否正确', async () =>{
      const name = await socialNetwork.name()
      assert.equal(name,'This is a test.')
    })
  })

  describe('posts', async () => {
    let result, postCount

    before(async () =>{
      result = await socialNetwork.createPost('This is a test.',{ from: author })//account[0]
      //author 对应 msg.sender 对应 author
      postCount = await socialNetwork.postCount()
    })

    it('创建传输', async () =>{
      //如果成功
      assert.equal(postCount, 1)

    //  console.log(event)

      const event = result.logs[0].args
      // 成功的情况
      assert.equal(event.id.toNumber(),postCount.toNumber(),'id正确')
      assert.equal(event.content,'This is a test.','合约正确')
      assert.equal(event.tipAmount,'0','账户的金额正确')
      assert.equal(event.author,author,'作者正确')

      //失败的情况
      //失败的情况
      await socialNetwork.createPost('', {from: author }).should.be.rejected;

    })

    it('展示传输', async () =>{
      const post = await socialNetwork.posts(postCount)
      assert.equal(post.id.toNumber(),postCount.toNumber(),'id正确')
      assert.equal(post.content,'This is a test.','合约正确')
      assert.equal(post.tipAmount,'0','账户的金额正确')
      assert.equal(post.author,author,'作者正确')
    })

    it('允许用户查看传输', async () =>{

      //查看用户之前的余额
      let oldAuthorBalance
      oldAuthorBalance = await web3.eth.getBalance(author)
      oldAuthorBalance = new web3.utils.BN(oldAuthorBalance)

      result = await socialNetwork.tipPost(postCount, {from: tipper, value: web3.utils.toWei('1','Ether')})
      const event = result.logs[0].args
      assert.equal(event.id.toNumber(),postCount.toNumber(),'id正确')
      assert.equal(event.content,'This is a test.','合约正确')
      assert.equal(event.tipAmount,'1000000000000000000','账户的金额正确')
      assert.equal(event.author,author,'作者正确')

      let newAuthorBalance
      newAuthorBalance = await web3.eth.getBalance(author)
      newAuthorBalance = new web3.utils.BN(newAuthorBalance)

      let tipAmount
      tipAmount = web3.utils.toWei('1','Ether')
      tipAmount = new web3.utils.BN(tipAmount)

      const exepectedBalance = oldAuthorBalance.add(tipAmount)

      assert.equal(exepectedBalance.toString(), newAuthorBalance.toString())

      //确保发送的地址有效
      await socialNetwork.tipPost(99, { from: tipper, value: web3.utils.toWei('1','Ether')}).should.be.rejected;
    })
  })
})
//async是为了使用await
//
//
//
//
//
//
//
//
//
//
//
//
//
//
